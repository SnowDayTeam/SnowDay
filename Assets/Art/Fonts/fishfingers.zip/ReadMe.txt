FISHfingers (c) Brittney Murphy 2013
www.brittneymurphydesign.com
info@brittneymurphydesign.com

"FISHfingers" is a font created and copyrighted by Brittney Murphy.

It is free for personal and non-profit use.  If you would like to use this font commercially, please pay $5 at www.brittneymurphydesign.com.

Please do not redistribute this font.

